export interface UserInterface{

  nombre: string,//nombre 
  apellido: string,//apellido
  doctoIdent: string,//documento de identidad 
  email: string,//correo electrónico (usuario)
  clave: string,//clave
  cia: string //para este campo siempre se debe enviar un 10
  
}