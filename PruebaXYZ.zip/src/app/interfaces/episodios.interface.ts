export interface EpisodiosInterface{

    results: [
        {
          id: number,
          name: string,
          air_date: Date,
          episode: string,
          characters: [],
          url:string,
          created: Date
        },
    ]
}