import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserInterface } from '../../interfaces/user.interface';

@Injectable({
  providedIn:'root'
})
export class UserServiceComponent {
  
    API_URL: String= 'https://pruebas.midasoft.co:5443/Apis_DLLO/Seleccion/api/SOL/RegistroInicialSolicitante';
    body:any;

    httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        Authorization: 'my-auth-token'
      })
    };    
  
    constructor(private httpClient: HttpClient){}

    AddUser(user:UserInterface):Observable<any>{
      this.body= JSON.stringify(user);
      return this.httpClient.post(this.API_URL.toString(),user,this.httpOptions);
    }


}

