import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn:'root'
})
export class EpisodiosSeriviceComponent {

  API_URL: String= 'https://rickandmortyapi.com/api/episode';
  API_URL_CHARACTER: String= 'https://rickandmortyapi.com/api/character';

  constructor(private httpClient: HttpClient){}
  
  getEpisodios():Observable<any>{
    debugger;
    return this.httpClient.get(this.API_URL.toString()).pipe(res=> res);
  }

    
  getCharacters():Observable<any>{
    debugger;
    return this.httpClient.get(this.API_URL_CHARACTER.toString()).pipe(res=> res);
  }

}
