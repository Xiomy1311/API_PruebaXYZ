import { Component, DebugElement, OnInit } from '@angular/core';
import { UserServiceComponent } from '../../services/usersServices/userServices.component';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatTableDataSource } from '@angular/material/table';
import { UserInterface } from '../../interfaces/user.interface';
import { EmptyExpr } from '@angular/compiler';
import { empty } from 'rxjs';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [FormsModule, MatInputModule,MatButtonModule],
  templateUrl: './users.component.html',
  styleUrl: './users.component.css',
})
export class UsersComponent implements OnInit  
{
   
  userInterface: UserInterface = {
    nombre: '',
    apellido:'',
    doctoIdent:'',
    email:'',
    clave:'',
    cia:''
    
  }

  constructor(private usersServices: UserServiceComponent) {}

 
  ngOnInit(): void {
    debugger;
    this.userInterface.cia= "10";
   
  }

  saveNewUser() {
    debugger;
    this.usersServices
      .AddUser(this.userInterface)
      .subscribe((resul) => console.log(resul));
      
  }
}
