import { Component, OnInit, ViewChild } from '@angular/core';
import { EpisodiosSeriviceComponent } from '../../services/episodiosServices/episodiosServices.component';
import { EpisodiosInterface } from '../../interfaces/episodios.interface';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { InfoEpisodiosInterface } from '../../interfaces/infoEpisodios.interface';



@Component({
  selector: 'app-episodios',
  standalone: true,
  imports: [MatTableModule,MatPaginatorModule],
  templateUrl: './episodios.component.html',
  styleUrl: './episodios.component.css'
})
export class EpisodiosComponent implements OnInit 
{
   dataSource:any;
   paginationSource:any;
   pageSize:any;
   totalSize :any;

  episosidiosList: EpisodiosInterface[]=[];
  infoEpisosidiosList: InfoEpisodiosInterface[]=[];
  
  columnas: string[] = ['id','name','air_Date','episode','url','created'];
  
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;

  constructor(private episiodiosServices: EpisodiosSeriviceComponent)  {}

  ngOnInit(): void {

    this.getEpisodios();
   
    this.dataSource = new MatTableDataSource<EpisodiosInterface>(this.episosidiosList);  
    this.paginationSource= new MatTableDataSource<InfoEpisodiosInterface>(this.infoEpisosidiosList);  
    this.dataSource.paginator=  this.paginator;
    this.pageSize= this.paginationSource.data.pages;
  
    console.log('dataSource',this.dataSource);
  }

getEpisodios()
{
  debugger;
  this.episiodiosServices.getEpisodios().subscribe({
    next:(result)=>{

     this.episosidiosList= result.results;
     this.infoEpisosidiosList= result.info;
    },
    error:(err)=>{
      console.log(err);
    }
  })
}

}
